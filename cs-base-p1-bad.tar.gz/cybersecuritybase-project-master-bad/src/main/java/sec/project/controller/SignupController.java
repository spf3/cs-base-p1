package sec.project.controller;

import java.util.List;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model; // Added
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import sec.project.domain.Account;
import sec.project.domain.Signup;
import sec.project.repository.AccountRepository;
import sec.project.repository.SignupRepository;

@Controller
public class SignupController {

    @Autowired
    private SignupRepository signupRepository;
    
    @Autowired
    private AccountRepository accountRepository;

    @RequestMapping(value = "/form", method = RequestMethod.GET)
    public String list(HttpServletRequest request, HttpServletResponse response, Model model) {
        
        String username = getUsername(request);
        
        Account account = accountRepository.findByUsername(username);
        System.out.println(account.getUsername());
        List<Signup> signups = account.getSignups();
        for(int i=0; i < signups.size(); i++) {
            System.out.println(signups.get(i).getEvent());
            System.out.println(signups.get(i).getLocation());
        }
        System.out.println(signups.size());
        model.addAttribute("username", username);
        model.addAttribute("signups", accountRepository.findByUsername(username).getSignups());
        return "form";
    }
    
    @RequestMapping(value = "/form", method = RequestMethod.POST)
    public String submitForm(HttpServletRequest request, HttpServletResponse response, @RequestParam String event, @RequestParam String location) {
        
        String username = getUsername(request);
        
        Account account = accountRepository.findByUsername(username);
        
        System.out.println("Saving...");
                
        Signup signup = new Signup(event, location);
        signup.setAccount(account);
        
        signupRepository.save(signup);
        return "redirect:/form";
    }
    
    private String getUsername (HttpServletRequest request) {
        Cookie[] cookies = request.getCookies();
        String username = null;
        if (cookies != null) {
            boolean cookieExists = false;
            for (int i = 0; i < cookies.length; i++) {
                if (cookies[i].getName().equals("uid")) {
                    username = cookies[i].getValue();
                }
            }
        }
        
        if (username == null) {
            username = "user" ;
        }
        
        return (username);
    }

}
