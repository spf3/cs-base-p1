package sec.project.controller;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import sec.project.domain.Account;
import sec.project.repository.AccountRepository;


@Controller
public class AuthController {

    @Autowired
    private AccountRepository accountRepository;
    
    @RequestMapping(value="/auth", method = RequestMethod.GET)
    public String authx() {
        System.out.println("authx()");
        return "auth";
    }
    
    @RequestMapping(value="/auth", method = RequestMethod.POST)
    public String auth(HttpServletRequest request, HttpServletResponse response, @RequestParam(required = false) String username, @RequestParam(required = false) String password) {
        System.out.println("auth");
        
        Account account = accountRepository.findByUsername(username);
        
        if (account == null) {
            return "auth";
        }
        
        String pwd = account.getPassword();
        
        if (password.equalsIgnoreCase(pwd)) {
            Cookie cookie1 = new Cookie("uid", username);
            response.addCookie(cookie1);
            Cookie cookie2 = new Cookie("pwd", password);
            response.addCookie(cookie2);
            return "redirect:/form";
        } else {
            return "auth";
        }
    }
}
