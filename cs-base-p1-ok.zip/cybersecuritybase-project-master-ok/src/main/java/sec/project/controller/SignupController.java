package sec.project.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model; // Added
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import sec.project.domain.Account;
import sec.project.domain.Signup;
import sec.project.repository.AccountRepository;
import sec.project.repository.SignupRepository;

@Controller
public class SignupController {

    @Autowired
    private SignupRepository signupRepository;
    
    @Autowired
    private AccountRepository accountRepository;

    @RequestMapping(value = "/form", method = RequestMethod.GET)
    public String list(Authentication authentication, Model model) {
            
        Account account = accountRepository.findByUsername(authentication.getName());
        String username = account.getUsername();
        
        System.out.println(username);
        List<Signup> signups = account.getSignups();
        for(int i=0; i < signups.size(); i++) {
            System.out.println(signups.get(i).getEvent());
            System.out.println(signups.get(i).getLocation());
        }
        System.out.println(signups.size());
        
        model.addAttribute("username", username);
        model.addAttribute("signups", accountRepository.findByUsername(username).getSignups());
        return "form";
    }
    
    @RequestMapping(value = "/form", method = RequestMethod.POST)
    public String submitForm(Authentication authentication, @RequestParam String event, @RequestParam String location) {
        
        Account account = accountRepository.findByUsername(authentication.getName());
        
        System.out.println("Saving...");
                
        Signup signup = new Signup(event, location);
        signup.setAccount(account);
        
        signupRepository.save(signup);
        return "redirect:/form";
    }
}
